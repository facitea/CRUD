<template>
  <div class="home">
    <img alt="Vue logo" src="../assets/logo.png">
    <HelloWorld msg="개발중인 Social Media입니다"/>
    <div>
        <input type="email" placeholder="email을 입력해주세용" id="email" value="" >
        </div>
        <div>
            <input type="password" placeholder="비밀번호를 입력해주세용" id="pw" value="">
        </div>
        <button v-on:click="onLoggin()">hey</button>
  </div>
</template>

<script>
// @ is an alias to /src
import HelloWorld from '@/components/HelloWorld.vue'
import axios from 'axios';

export default {
  name: 'HomeView',
  components: {
    HelloWorld
  },
  methods: {
    onLoggin(){
            const email = document.getElementById("email");
            const password = document.getElementById('pw')
            axios({
                method:"POST",
                url: 'https://reqres.in/api/login',
                data:{
                    "email": email.value,
                    "password": password.value
                }
            }).then((res)=>{
                console.log(res);
            }).catch(error=>{
                console.log(error);
                throw new Error(error);
            });
  }
}


}
</script>
