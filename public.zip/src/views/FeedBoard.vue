<template>
  <div>
    <div>
        <WriteDown />
    </div>
  </div>
</template>

<script>
    import WriteDown from '@/components/WriteDown.vue'

    export default {
    name: 'FeedBoard',
    components: {
        WriteDown
        }
    }

    
</script>

<style scoped>

</style>